#pragma once
#include "CpuidTypes.h"
//#include "IntelPmxTypes.h"
#include "UefiTypes.h"


/// EOF