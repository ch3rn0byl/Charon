#pragma once
#include <Windows.h>

class Privileges
{
public:
	bool CheckAdminPrivileges();

private:

};

